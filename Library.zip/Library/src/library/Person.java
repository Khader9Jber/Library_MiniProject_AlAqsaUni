package library;

public class Person {

    private String personId;
    private String personName;
    private String personGender;
    private String personPhone;
    private String address;

    public Person() {
    }

    public Person(String personId, String personName, String personGender, String personPhone, String address) {
        this.personId = personId;
        this.personName = personName;
        this.personGender = personGender;
        this.personPhone = personPhone;
        this.address = address;
    }

    public String getPersonId() {
        return personId;
    }

    public void setPersonId(String personId) {
        this.personId = personId;
    }

    public String getPersonName() {
        return personName;
    }

    public void setPersonName(String personName) {
        this.personName = personName;
    }

    public String getPersonGender() {
        return personGender;
    }

    public void setPersonGender(String personGender) {
        this.personGender = personGender;
    }

    public String getPersonPhone() {
        return personPhone;
    }

    public void setPersonPhone(String personPhone) {
        this.personPhone = personPhone;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    @Override
    public String toString() {
        return "Id = " + personId + ", Name = " + personName + ", Gender = " + personGender + ", Phone = " + personPhone + ", Address=" + address;
    }

   
    

}
