package library;

public class Student extends Person {

    private String studentId;
    private String studentEnrolledDate;
    private String specialization;
    private double studentBudget;

    public Student() {
    }

    public Student(String studentId, String studentEnrolledDate, String specialization, double studentBudget, String personId, String personName, String personGender, String personPhone, String address) {
        super(personId, personName, personGender, personPhone, address);
        this.studentId = studentId;
        this.studentEnrolledDate = studentEnrolledDate;
        this.specialization = specialization;
        this.studentBudget = studentBudget;
    }

    public String getStudentId() {
        return studentId;
    }

    public void setStudentId(String studentId) {
        this.studentId = studentId;
    }

    public String getStudentEnrolledDate() {
        return studentEnrolledDate;
    }

    public void setStudentEnrolledDate(String studentEnrolledDate) {
        this.studentEnrolledDate = studentEnrolledDate;
    }

    public String getSpecialization() {
        return specialization;
    }

    public void setSpecialization(String specialization) {
        this.specialization = specialization;
    }

    public double getStudentBudget() {
        return studentBudget;
    }

    public void setStudentBudget(double studentBudget) {
        this.studentBudget = studentBudget;
    }

    @Override
    public String toString() {
        return super.toString() + " StudentId = " + studentId + ", Student Enrolled Date = " + studentEnrolledDate + ", Specialization = " + specialization + ", Student Budget=" + studentBudget;
    }

}
