package library;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Process {

    static Scanner in = new Scanner(System.in);
    private static ArrayList<Book> arrB = new ArrayList<>();
    private static ArrayList<Student> arrS = new ArrayList<>();
    private static Book b;
    private static Student s;
    private static Author a;

    public static void menu() throws IOException {

        int ch;
        do {
            System.out.println("\n-------------------------------------------");
            System.out.println("Hello! What do want to do in the library?");
            System.out.println("1. Show Books\n"
                    + "2. Add a Book\n"
                    + "3. Delete a Book\n"
                    + "4. Search for a book\n"
                    + "5. Buy a Book\n"
                    + "6. Show Students\n"
                    + "7. Add a Student\n"
                    + "8. Full Report\n"
                    + "9. Exit");
            System.out.println("Enter your choice:");
            System.out.println("\n-------------------------------------------");

            ch = in.nextInt();
            switch (ch) {
                case 1:
                    showBook();
                    break;
                case 2:
                    addBook();
                    break;
                case 3:
                    System.out.println("Enter the Name of the book:");
                    String name = in.next();
                    deletBook(name);
                    break;
                case 4:
                    System.out.println("We search based on name or Categury..\nEnter name & Categury:");
                    search4Book(in.next(), in.next());
                    break;
                case 5:
                    System.out.println("Enter the name of the book:");
                    String namebook = in.next();
                    System.out.println("Enter ID person number:");
                    String idPerson = in.next();
                    buyBook(namebook, idPerson);
                    break;
                case 6:
                    String showStudents = showStudents();
                    System.out.println(showStudents);
                    break;
                case 7:
                    addStudent();
                    break;
                case 8:
                    fullReport();
                    break;
                case 9:
                    System.out.println("Good-bye *_^ ");
                    System.exit(0);
                    break;
                default:
                    System.out.println("Invalid Choice!");
            }

        } while (ch != 9);

    }

    private static void showBook() {
        if (arrB.size() >= 1) {
            for (Book book : arrB) {
                System.out.println(book.toString());
                System.out.println("-----------------------------------------------------");
            }
        } else {
            System.out.println("There is no Book yet!");
        }

    }//done.

    private static void addBook() {
        b = new Book();
        a = new Author();
        System.out.println("Enter the book ID:");
        b.setBookId(in.next());
        System.out.println("Enter the book name:");
        b.setBookName(in.next());
        System.out.println("Enter the book Categury:");
        b.setCategory(in.next());
        System.out.println("Enter the book publisher:");
        b.setPublisher(in.next());
        System.out.println("Enter the year of publication:");
        b.setEditionYear(in.next());
        System.out.println("Enter the book quntity:");
        b.setQuantity(in.nextInt());
        System.out.println("Enter the book price:");
        b.setPrice(in.nextDouble());

        System.out.println("-----------------------------------------------------");

        System.out.println("Enter the auther Information:");
        System.out.println("Name of Author:");
        a.setPersonName(in.next());
        System.out.println("Enter ID:");
        a.setPersonId(in.next());
        System.out.println("Enter Gender:");
        a.setPersonGender(in.next());
        System.out.println("Enter phone:");
        a.setPersonPhone(in.next());
        System.out.println("E-Mail:");
        a.setAuthorEmail(in.next());
        System.out.println("Enter WorkPlace:");
        a.setWorkPlace(in.next());
        b.setBookAuthor(a);
        arrB.add(b);
        System.out.println("The book has been added successfully!!");
    }//done.

    private static void deletBook(String name) {
        boolean isDeleted = false;
        for (Book book : arrB) {
            if (book.getBookName().equalsIgnoreCase(name)) {
                arrB.remove(book);
                isDeleted = true;
            }
        }
        if (isDeleted) {
            System.out.println("This book has been successfully deleted!!");
        } else {
            System.out.println("There is no book has the same name!!");
        }
    }//done.

    private static void search4Book(String name, String cat) {
        ArrayList<Book> searchBooks = new ArrayList<>();
        for (Book book : arrB) {
            if (book.getBookName().equalsIgnoreCase(name) || book.getCategory().equalsIgnoreCase(cat)) {
                arrB.add(book);
            }
        }
        if (searchBooks.size() < 1) {
            System.out.println("There is no book has the same detils.");

        } else {
            for (Book searchBook : searchBooks) {
                searchBook.toString();
            }
        }
    }//done.

    private static void buyBook(String namebook, String idPerson) {
        b = null;
        s = null;
        for (Book book : arrB) {
            if (book.getBookName().equalsIgnoreCase(namebook)) {
                b = book;
                for (Student student : arrS) {
                    if (student.getPersonId().equalsIgnoreCase(idPerson)) {
                        s = student;
                        b.addStudent(s);
                        return;
                    }
                }
                break;
            }
        }
        System.out.println("There is no student or book has the same details!!");
    }//done.

    private static void addStudent() {
        s = new Student();
        System.out.println("Enter the name of student:");
        s.setPersonName(in.next());
        System.out.println("Enter person ID:");
        s.setPersonId(in.next());
        System.out.println("Enter Student Id:");
        s.setStudentId(in.next());
        System.out.println("Enter gender:");
        s.setPersonGender(in.next());
        System.out.println("Enter adress:");
        s.setAddress(in.next());
        System.out.println("Enter Phone number:");
        s.setPersonPhone(in.next());
        System.out.println("Enter student Enrolled Date:");
        s.setStudentEnrolledDate(in.next());
        System.out.println("Enter specialization:");
        s.setSpecialization(in.next());
        System.out.println("Enter Student Budget:");
        s.setStudentBudget(in.nextDouble());

        arrS.add(s);
        System.out.println("The student has been added succesfully!!");
    }//done.

    private static String showStudents() {
        String ret = "";
        if (arrS.size() >= 1) {
            for (Student s : arrS) {
                ret += s.toString() + "\n";
            }
        } else {
            ret += "There is no Student yet!";
        }
        return ret;
    }//done.

    private static void fullReport() {
        String workingDirectory = System.getProperty("user.dir");
        boolean dirMade = false;
        //boolean fileMaked = false;
        File dir = new File(workingDirectory + "\\Prog"); //C:\Users\HP\Documents\NetBeansProject\Library
        if (!dir.exists()) {
            dir.mkdir();
            dirMade = true;
        }
        File file = new File(dir.getPath() + "\\Repot.txt");
        if (!file.exists() && dirMade) {
            try {
                file.createNewFile();
                //fileMaked = true;
                FileWriter fr = new FileWriter(file);
                PrintWriter pr = new PrintWriter(fr);
                if (arrB.size() < 1) {
                    pr.println("There is no Book yet!\n");
                    pr.println("---------------------------------------\n");
                    pr.println("There is no student bought this book!\n");
                } else {
                    for (Book book : arrB) {
                        pr.println(book.toString() + "\n");
                    }
                }
                System.out.println("The report has been printed succesfully!");
                fr.close();
                pr.close();
            } catch (IOException ex) {
                System.err.println("Something wrong!!");
            }

        }
        System.out.println("The report was not printed!\nDelete the old report to print another one.");
    }

}
