package library;

public class Author extends Person {

    private int noOfBooks;
    private String authorEmail;
    private String workPlace;

    public Author() {
    }

    public Author(int noOfBooks, String authorEmail, String workPlace, String personId, String personName, String personGender, String personPhone, String address) {
        super(personId, personName, personGender, personPhone, address);
        this.noOfBooks = noOfBooks;
        this.authorEmail = authorEmail;
        this.workPlace = workPlace;
    }

    public int getNoOfBooks() {
        return noOfBooks;
    }

    public void setNoOfBooks(int noOfBooks) {
        this.noOfBooks = noOfBooks;
    }

    public String getAuthorEmail() {
        return authorEmail;
    }

    public void setAuthorEmail(String authorEmail) {
        this.authorEmail = authorEmail;
    }

    public String getWorkPlace() {
        return workPlace;
    }

    public void setWorkPlace(String workPlace) {
        this.workPlace = workPlace;
    }

    @Override
    public String toString() {
        return super.toString() +  "Number Of Books = " + noOfBooks + ", Author Email=" + authorEmail + ", Work Place=" + workPlace;
    }

}
