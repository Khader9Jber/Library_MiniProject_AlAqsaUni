package library;

import java.io.IOException;

public class Library {

    public static void main(String[] args) throws IOException {
        Process p = new Process();
        Process.menu();
    }

}
