package library;

public class Book {

    private String bookId;
    private String bookName;
    private String bookCategory;
    private String Publisher;
    private String editionYear;
    private Author bookAuthor;
    private double Price;
    private int quantity;
    private Student[] students;

    public Book() {
        this.students = new Student[quantity];
    }

    public Book(String bookId, String bookName, String bookCategory, Author bookAuthor, String Publisher, String editionYear, double Price, int quantity) {
        this.bookId = bookId;
        this.bookName = bookName;
        this.bookCategory = bookCategory;
        this.bookAuthor = bookAuthor;
        this.Publisher = Publisher;
        this.editionYear = editionYear;
        this.Price = Price;
        this.quantity = quantity;
        this.students = new Student[quantity];
    }

    public String getBookId() {
        return bookId;
    }

    public void setBookId(String bookId) {
        this.bookId = bookId;
    }

    public String getBookName() {
        return bookName;
    }

    public void setBookName(String bookName) {
        this.bookName = bookName;
    }

    public String getCategory() {
        return bookCategory;
    }

    public void setCategory(String category) {
        this.bookCategory = category;
    }

    public Author getBookAuthor() {
        return bookAuthor;
    }

    public void setBookAuthor(Author bookAuthor) {
        this.bookAuthor = bookAuthor;
    }

    public String getPublisher() {
        return Publisher;
    }

    public void setPublisher(String Publisher) {
        this.Publisher = Publisher;
    }

    public String getEditionYear() {
        return editionYear;
    }

    public void setEditionYear(String editionYear) {
        this.editionYear = editionYear;
    }

    public double getPrice() {
        return Price;
    }

    public void setPrice(double Price) {
        this.Price = Price;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        students = new Student[quantity];
        this.quantity = quantity;
    }

    public Student[] getStudents() {
        return students;
    }

    public void setStudents(Student[] students) {
        this.students = students;
    }

    @Override
    public String toString() {
        String stuInfo = "";
        if (quantity == students.length) {
            stuInfo = "There is no student purchased this book.\n";
        } else {
            stuInfo = "The students purchased this book are.\n";
            for (int i = 0; i < (students.length - quantity); i++) {
                stuInfo += students[i].toString() + "\n"; //.toString() + "\n"
            }
        }
        return "Book Id = " + bookId + ", Book Name = " + bookName + ", Book Category = " + bookCategory + ", Book Author = " + bookAuthor + ", Publisher = " + Publisher + ", Edition Year = " + editionYear + ", Price = " + Price + ", Quantity = " + quantity + "\n" + "Students Info" + stuInfo;
    }

    public void addStudent(Student stu) {
        if (stu.getStudentBudget() >= getPrice()) {
            if (quantity > 0) {
                students[students.length - quantity] = stu;///////////////////////////////////////////
                stu.setStudentBudget(stu.getStudentBudget() - Price);
                quantity--;
            } else {
                System.out.println("There is no available copies!");
            }
        } else {
            System.out.println("This student does not have monay enough!");
        }
    }

}
